# مشروع أمن مخيزنة - الكود الكامل
## نظام البلاغات الأمنية المتقدم

### معلومات المشروع
- **اسم المشروع**: أمن مخيزنة (Mukhayzna Security)
- **النوع**: نظام بلاغات أمنية شامل
- **التقنيات**: React.js, Express.js, PostgreSQL, Drizzle ORM
- **الميزات**: متعدد اللغات (عربي/إنجليزي), تتبع GPS, رفع الملفات
- **المطور**: خالد البحري

---

## 📁 هيكل المشروع

```
├── client/                     # الواجهة الأمامية (React)
│   ├── src/
│   │   ├── components/         # المكونات المشتركة
│   │   ├── hooks/             # خطافات مخصصة
│   │   ├── lib/               # مكتبات مساعدة
│   │   ├── pages/             # صفحات التطبيق
│   │   └── index.css          # أنماط CSS الرئيسية
│   └── index.html             # ملف HTML الأساسي
├── server/                    # الخادم الخلفي (Express)
│   ├── index.ts              # نقطة دخول الخادم
│   ├── routes.ts             # مسارات API
│   ├── storage.ts            # طبقة قاعدة البيانات
│   ├── db.ts                 # إعدادات قاعدة البيانات
│   └── vite.ts               # إعدادات Vite
├── shared/                   # الكود المشترك
│   └── schema.ts             # مخططات قاعدة البيانات
├── uploads/                  # مجلد رفع الملفات
├── package.json              # تبعيات المشروع
├── tailwind.config.ts        # إعدادات Tailwind CSS
├── vite.config.ts           # إعدادات Vite
└── drizzle.config.ts        # إعدادات Drizzle ORM
```

---

## 📦 package.json

```json
{
  "name": "rest-express",
  "version": "1.0.0",
  "type": "module",
  "license": "MIT",
  "scripts": {
    "dev": "NODE_ENV=development tsx server/index.ts",
    "build": "vite build && esbuild server/index.ts --platform=node --packages=external --bundle --format=esm --outdir=dist",
    "start": "NODE_ENV=production node dist/index.js",
    "check": "tsc",
    "db:push": "drizzle-kit push"
  },
  "dependencies": {
    "@hookform/resolvers": "^3.10.0",
    "@neondatabase/serverless": "^0.10.4",
    "@radix-ui/react-accordion": "^1.2.4",
    "@radix-ui/react-alert-dialog": "^1.1.7",
    "@radix-ui/react-avatar": "^1.1.4",
    "@radix-ui/react-checkbox": "^1.1.5",
    "@radix-ui/react-dialog": "^1.1.7",
    "@radix-ui/react-dropdown-menu": "^2.1.7",
    "@radix-ui/react-label": "^2.1.3",
    "@radix-ui/react-popover": "^1.1.7",
    "@radix-ui/react-select": "^2.1.7",
    "@radix-ui/react-separator": "^1.1.3",
    "@radix-ui/react-slot": "^1.2.0",
    "@radix-ui/react-switch": "^1.1.4",
    "@radix-ui/react-tabs": "^1.1.4",
    "@radix-ui/react-toast": "^1.2.7",
    "@tanstack/react-query": "^5.60.5",
    "class-variance-authority": "^0.7.1",
    "clsx": "^2.1.1",
    "connect-pg-simple": "^10.0.0",
    "cookie-parser": "^1.4.7",
    "date-fns": "^3.6.0",
    "drizzle-orm": "^0.39.1",
    "drizzle-zod": "^0.7.0",
    "express": "^4.21.2",
    "express-session": "^1.18.1",
    "framer-motion": "^11.13.1",
    "lucide-react": "^0.453.0",
    "multer": "^2.0.1",
    "react": "^18.3.1",
    "react-dom": "^18.3.1",
    "react-hook-form": "^7.55.0",
    "recharts": "^2.15.3",
    "tailwind-merge": "^2.6.0",
    "wouter": "^3.3.5",
    "zod": "^3.24.2"
  }
}
```

---

## 🗄️ مخططات قاعدة البيانات (shared/schema.ts)

```typescript
import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  integer,
  serial,
  decimal,
  boolean,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// جدول المستخدمين
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// جدول الجلسات
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// جدول كودات التحقق
export const verificationCodes = pgTable("verification_codes", {
  id: serial("id").primaryKey(),
  phoneNumber: varchar("phone_number").notNull(),
  code: varchar("code").notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// جدول الموظفين
export const employees = pgTable("employees", {
  id: serial("id").primaryKey(),
  employeeId: varchar("employee_id").unique().notNull(),
  name: varchar("name").notNull(),
  department: varchar("department").notNull(),
  phoneNumber: varchar("phone_number"),
  createdAt: timestamp("created_at").defaultNow(),
});

// جدول البلاغات
export const reports = pgTable("reports", {
  id: serial("id").primaryKey(),
  duty: varchar("duty").notNull(),
  location: text("location").notNull(),
  notes: text("notes").notNull(),
  timestamp: timestamp("timestamp").defaultNow(),
  locationAccuracy: decimal("location_accuracy"),
  mediaFileName: varchar("media_file_name"),
  mediaFileSize: integer("media_file_size"),
  mediaFileType: varchar("media_file_type"),
  createdAt: timestamp("created_at").defaultNow(),
});

// جدول جهات الاتصال الطارئة
export const emergencyContacts = pgTable("emergency_contacts", {
  id: serial("id").primaryKey(),
  name: varchar("name").notNull(),
  phoneNumber: varchar("phone_number").notNull(),
  department: varchar("department").notNull(),
  priority: varchar("priority"),
  createdAt: timestamp("created_at").defaultNow(),
});

// جدول طلبات الإجازات
export const leaveRequests = pgTable("leave_requests", {
  id: serial("id").primaryKey(),
  employeeName: varchar("employee_name").notNull(),
  employeeId: varchar("employee_id").notNull(),
  leaveType: varchar("leave_type").notNull(),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  reason: text("reason").notNull(),
  status: varchar("status").default("pending"),
  createdAt: timestamp("created_at").defaultNow(),
});

// مخططات التحقق
export const phoneVerificationSchema = z.object({
  phoneNumber: z.string().min(1, "رقم الهاتف مطلوب"),
});

export const verifyCodeSchema = z.object({
  phoneNumber: z.string().min(1, "رقم الهاتف مطلوب"),
  code: z.string().min(4, "الكود يجب أن يكون 4 أرقام على الأقل"),
});

export const insertEmergencyContactSchema = createInsertSchema(emergencyContacts).omit({
  id: true,
  createdAt: true,
});

export const insertReportSchema = createInsertSchema(reports).omit({
  id: true,
  createdAt: true,
});

export const insertLeaveRequestSchema = createInsertSchema(leaveRequests).omit({
  id: true,
  createdAt: true,
  status: true,
});

export const employeeLoginSchema = z.object({
  employeeId: z.string().min(1, "رقم الموظف مطلوب"),
  phoneNumber: z.string().min(1, "رقم الهاتف مطلوب"),
});

// الأنواع المستخرجة
export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Employee = typeof employees.$inferSelect;
export type InsertEmployee = typeof employees.$inferInsert;
export type VerificationCode = typeof verificationCodes.$inferSelect;
export type Session = typeof sessions.$inferSelect;
export type EmergencyContact = typeof emergencyContacts.$inferSelect;
export type InsertEmergencyContact = z.infer<typeof insertEmergencyContactSchema>;
export type InsertReport = z.infer<typeof insertReportSchema>;
export type Report = typeof reports.$inferSelect;
export type LeaveRequest = typeof leaveRequests.$inferSelect;
export type InsertLeaveRequest = z.infer<typeof insertLeaveRequestSchema>;
export type PhoneVerification = z.infer<typeof phoneVerificationSchema>;
export type VerifyCode = z.infer<typeof verifyCodeSchema>;
export type EmployeeLogin = z.infer<typeof employeeLoginSchema>;
```

---

## 🔧 إعدادات قاعدة البيانات (server/db.ts)

```typescript
import { Pool, neonConfig } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-serverless';
import ws from "ws";
import * as schema from "@shared/schema";

neonConfig.webSocketConstructor = ws;

if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL must be set. Did you forget to provision a database?",
  );
}

export const pool = new Pool({ connectionString: process.env.DATABASE_URL });
export const db = drizzle({ client: pool, schema });
```

---

## 📊 طبقة قاعدة البيانات (server/storage.ts)

```typescript
import {
  reports,
  emergencyContacts,
  employees,
  sessions,
  leaveRequests,
  type Report,
  type InsertReport,
  type EmergencyContact,
  type InsertEmergencyContact,
  type Employee,
  type InsertEmployee,
  type Session,
  type LeaveRequest,
  type InsertLeaveRequest,
} from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";
import { randomUUID } from "crypto";

export interface IStorage {
  // طرق البلاغات
  createReport(report: InsertReport & { mediaFileName?: string | null; mediaFileSize?: number | null; mediaFileType?: string | null }): Promise<Report>;
  getReports(): Promise<Report[]>;
  getReportById(id: number): Promise<Report | undefined>;
  
  // طرق جهات الاتصال الطارئة
  getEmergencyContacts(): Promise<EmergencyContact[]>;
  createEmergencyContact(contact: InsertEmergencyContact): Promise<EmergencyContact>;
  updateEmergencyContact(id: number, contact: Partial<InsertEmergencyContact>): Promise<EmergencyContact | undefined>;
  deleteEmergencyContact(id: number): Promise<boolean>;

  // طرق تسجيل دخول الموظفين
  getEmployeeByEmployeeId(employeeId: string): Promise<Employee | undefined>;
  createEmployee(employee: InsertEmployee): Promise<Employee>;
  createSession(employeeId: number): Promise<Session>;
  getSessionById(sessionId: string): Promise<Session | undefined>;
  deleteSession(sessionId: string): Promise<boolean>;

  // طرق طلبات الإجازة
  createLeaveRequest(request: InsertLeaveRequest): Promise<LeaveRequest>;
  getLeaveRequests(): Promise<LeaveRequest[]>;
}

export class DatabaseStorage implements IStorage {
  async createReport(insertReport: InsertReport & { mediaFileName?: string | null; mediaFileSize?: number | null; mediaFileType?: string | null }): Promise<Report> {
    const [report] = await db
      .insert(reports)
      .values(insertReport)
      .returning();
    return report;
  }

  async getReports(): Promise<Report[]> {
    return await db.select().from(reports).orderBy(reports.createdAt);
  }

  async getReportById(id: number): Promise<Report | undefined> {
    const [report] = await db.select().from(reports).where(eq(reports.id, id));
    return report;
  }

  async getEmergencyContacts(): Promise<EmergencyContact[]> {
    return await db.select().from(emergencyContacts).orderBy(emergencyContacts.name);
  }

  async createEmergencyContact(contact: InsertEmergencyContact): Promise<EmergencyContact> {
    const [newContact] = await db
      .insert(emergencyContacts)
      .values(contact)
      .returning();
    return newContact;
  }

  async updateEmergencyContact(id: number, contact: Partial<InsertEmergencyContact>): Promise<EmergencyContact | undefined> {
    const [updatedContact] = await db
      .update(emergencyContacts)
      .set(contact)
      .where(eq(emergencyContacts.id, id))
      .returning();
    return updatedContact;
  }

  async deleteEmergencyContact(id: number): Promise<boolean> {
    const result = await db
      .delete(emergencyContacts)
      .where(eq(emergencyContacts.id, id));
    return result.rowCount > 0;
  }

  async getEmployeeByEmployeeId(employeeId: string): Promise<Employee | undefined> {
    const [employee] = await db.select().from(employees).where(eq(employees.employeeId, employeeId));
    return employee;
  }

  async createEmployee(employee: InsertEmployee): Promise<Employee> {
    const [newEmployee] = await db
      .insert(employees)
      .values(employee)
      .returning();
    return newEmployee;
  }

  async createSession(employeeId: number): Promise<Session> {
    const sessionId = randomUUID();
    const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 ساعة
    
    const sessionData = {
      sid: sessionId,
      sess: { employeeId },
      expire: expiresAt,
    };

    const [session] = await db
      .insert(sessions)
      .values(sessionData)
      .returning();
    return session;
  }

  async getSessionById(sessionId: string): Promise<Session | undefined> {
    const [session] = await db.select().from(sessions).where(eq(sessions.sid, sessionId));
    return session;
  }

  async deleteSession(sessionId: string): Promise<boolean> {
    const result = await db
      .delete(sessions)
      .where(eq(sessions.sid, sessionId));
    return result.rowCount > 0;
  }

  async createLeaveRequest(request: InsertLeaveRequest): Promise<LeaveRequest> {
    const [newRequest] = await db
      .insert(leaveRequests)
      .values(request)
      .returning();
    return newRequest;
  }

  async getLeaveRequests(): Promise<LeaveRequest[]> {
    return await db.select().from(leaveRequests).orderBy(leaveRequests.createdAt);
  }
}

export const storage = new DatabaseStorage();
```

سأستكمل بقية الأكواد في الرد التالي...